(() => {
  const main = document.querySelector('main');
  const nav = document.querySelector('.links');
  const burger = document.querySelector('.burger');

  if (!main) return;

  const normalisePath = (pathname) => {
    const clean = pathname.replace(/\/+$/, '').replace(/\.html$/, '');
    return clean || '/';
  };

  const updateCurrentLink = (pathname) => {
    if (!nav) return;
    const current = normalisePath(pathname);
    nav.querySelectorAll('a[href]').forEach((link) => {
      const linkUrl = new URL(link.href, window.location.origin);
      if (linkUrl.origin === window.location.origin &&
          normalisePath(linkUrl.pathname) === current) {
        link.setAttribute('aria-current', 'page');
      } else {
        link.removeAttribute('aria-current');
      }
    });
  };

  const updateHead = (nextDocument) => {
    document.title = nextDocument.title || document.title;
    const selectors = [
      'meta[name="description"]',
      'meta[property="og:title"]',
      'meta[property="og:description"]',
      'meta[property="og:type"]'
    ];

    selectors.forEach((selector) => {
      const nextMeta = nextDocument.head.querySelector(selector);
      const currentMeta = document.head.querySelector(selector);
      if (nextMeta && currentMeta) {
        currentMeta.setAttribute('content', nextMeta.getAttribute('content') || '');
      }
    });
  };

  const closeMobileMenu = () => {
    if (nav) nav.classList.remove('open');
    if (burger) burger.setAttribute('aria-expanded', 'false');
  };

  const renderDocument = (nextDocument, url, addHistoryEntry) => {
    const nextMain = nextDocument.querySelector('main');
    if (!nextMain) {
      window.location.href = url.href;
      return;
    }

    main.innerHTML = nextMain.innerHTML;
    updateHead(nextDocument);
    updateCurrentLink(url.pathname);
    closeMobileMenu();

    if (addHistoryEntry) {
      history.pushState({ page: true }, '', url.pathname + url.search + url.hash);
    }

    window.scrollTo(0, 0);
    const heading = main.querySelector('h1');
    if (heading) {
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
    }
  };

  const navigate = async (url, addHistoryEntry = true) => {
    try {
      const response = await fetch(url.href, {
        headers: { 'X-Requested-With': 'fetch' },
        credentials: 'same-origin'
      });
      if (!response.ok) throw new Error(`Navigation failed: ${response.status}`);

      const html = await response.text();
      const nextDocument = new DOMParser().parseFromString(html, 'text/html');
      if (!nextDocument.querySelector('main')) throw new Error('Page content missing');

      if (typeof document.startViewTransition === 'function') {
        const transition = document.startViewTransition(() => {
          renderDocument(nextDocument, url, addHistoryEntry);
        });
        await transition.updateCallbackDone;
      } else {
        main.classList.remove('page-enter');
        renderDocument(nextDocument, url, addHistoryEntry);
        void main.offsetWidth;
        main.classList.add('page-enter');
      }
    } catch (error) {
      // A normal browser navigation is the reliable fallback if fetch/transition fails.
      window.location.href = url.href;
    }
  };

  // A gentle first appearance; content remains visible if motion is reduced.
  main.classList.add('page-enter');
  main.addEventListener('animationend', () => main.classList.remove('page-enter'), { once: true });

  // Intercept every same-site page link, including the logo and Hire Me button.
  document.addEventListener('click', (event) => {
    const link = event.target.closest('a[href]');
    if (!link || event.defaultPrevented || event.button !== 0 ||
        event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ||
        link.hasAttribute('download') ||
        (link.target && link.target !== '_self')) return;

    const url = new URL(link.href, window.location.href);
    if (url.origin !== window.location.origin ||
        (url.pathname === window.location.pathname && url.search === window.location.search) ||
        (url.hash && url.pathname === window.location.pathname)) return;

    event.preventDefault();
    navigate(url);
  });

  if (burger && nav) {
    burger.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      burger.setAttribute('aria-expanded', String(isOpen));
    });
  }

  // Keep the contact form working after its page is swapped into the document.
  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!form.matches('#wa-form')) return;
    event.preventDefault();

    const data = new FormData(form);
    const message = `Hello Ordia, I'm ${data.get('name')}. Project: ${data.get('type')}. ${data.get('msg')} (Email: ${data.get('email')})`;
    window.location.href = 'https://wa.me/2347048603206?text=' + encodeURIComponent(message);
  });

  window.addEventListener('popstate', () => {
    navigate(new URL(window.location.href), false);
  });

  updateCurrentLink(window.location.pathname);
})();
