const b=document.querySelector('.burger'),l=document.querySelector('.links');
if(b)b.addEventListener('click',()=>{const o=l.classList.toggle('open');b.setAttribute('aria-expanded',o)});
const f=document.getElementById('wa-form');
if(f)f.addEventListener('submit',e=>{e.preventDefault();const d=new FormData(f);
const t=`Hello Ordia, I'm ${d.get('name')}. Project: ${d.get('type')}. ${d.get('msg')} (Email: ${d.get('email')})`;
location.href='https://wa.me/2347048603206?text='+encodeURIComponent(t)});
